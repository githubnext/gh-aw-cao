import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync, statSync } from "node:fs";
import test from "node:test";
import { readJsonArchive } from "../../.github/skills/add-operational-value/scripts/json-archive.mjs";
import { scope } from "../../scripts/investigate-weekly-editors-health-check.mjs";

const report = readJsonArchive("docs/operational-value/proof/weekly-editors-health-check/investigation.json");

test("offline editor investigation preserves frozen source and complete inventory identity", () => {
  assert.deepEqual(report.scope, scope);
  assert.equal(report.outputHistory.index.repositoryId, scope.repositoryId);
  assert.equal(report.outputHistory.index.sourceRevision, scope.revision);
  assert.equal(report.outputHistory.index.until, scope.cutoff);
  assert.equal(report.outputHistory.index.complete, true);
  assert.equal(report.outputHistory.inspectedEntities, report.outputHistory.index.totalEntities);
  assert.equal(report.outputHistory.index.partitions.reduce((sum, part) => sum + part.count, 0),
    report.outputHistory.inspectedEntities);
  assert.equal(report.outputHistory.candidates.length, 18);
  assert.equal(new Set(report.outputHistory.candidates.map(row => row.id)).size, 18);
  assert.ok(report.outputHistory.candidates.every(row =>
    row.workflowReference.workflowId === scope.workflow && Date.parse(row.createdAt) < Date.parse(scope.cutoff)));
});

test("pending compiled source is explicit and candidate claims do not become HTTP measurements", () => {
  assert.equal(report.readiness.function, "independent-function-verification-required");
  assert.equal(report.readiness.nativeHttpReceipts, 0);
  assert.equal(report.readiness.nativeOutcomeCount, null);
  assert.equal(report.readiness.historicalCoverage, "unknown");
  assert.equal(report.sources.length, 5);
  assert.equal(report.sources.filter(row => row.available).length, 4);
  for (const row of report.sources.filter(row => !row.available)) {
    assert.equal(row.pendingEndpoint, `repos/${scope.repository}/git/blobs/${row.blob}`);
    assert.ok(row.missingReason.length > 0);
  }
  assert.ok(report.pending.every(row => row.approval === "required-before-network"));
  assert.ok(report.pending.every(row => !row.endpoint.includes("undefined")));
  assert.ok(report.pending.filter(row => row.attempt).every(row => row.attempt.includes("Unverified")));
  assert.equal(report.adoption.source.blob, "8031eea07e2c2e113d9c13703262b6b8db057725");
  assert.equal(report.adoption.predecessor, "");
  for (const row of [...report.sources, ...report.inventoryHistory].filter(row => row.available)) {
    const bytes = Buffer.from(row.content, "base64");
    assert.equal(createHash("sha256").update(bytes).digest("hex"), row.sha256);
    assert.equal(createHash("sha1").update(`blob ${bytes.length}\0`).update(bytes).digest("hex"), row.blob);
  }
});

test("retained investigation archive satisfies the portable per-file budget", () => {
  const file = "docs/operational-value/proof/weekly-editors-health-check/investigation.json";
  const raw = JSON.parse(readFileSync(file));
  for (const name of [file, ...(raw.parts ?? []).map(part =>
    `docs/operational-value/proof/weekly-editors-health-check/${part.file}`)]) {
    assert.ok(statSync(name).size <= 256 * 1024, name);
    assert.match(createHash("sha256").update(readFileSync(name)).digest("hex"), /^[a-f0-9]{64}$/);
  }
});
