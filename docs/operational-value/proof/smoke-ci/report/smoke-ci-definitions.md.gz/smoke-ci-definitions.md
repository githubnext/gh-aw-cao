---
title: "What Smoke CI measures"
description: "Definitions, evidence rules, and interpretation for the Smoke CI operational-value report."
---

This page explains the operational-value timeline in plain language. It defines what was measured; it does not decide whether an agent or workflow caused the observed changes.

## Value review

**Assessment:** not-rated. No agreed native keep bar and review duration.

**Latest repository outcome:** unknown effects; unavailable

**Measurement:** interval; 1-day window, 1-day cadence.

**Recent change:** unavailable: Fresh complete mature evidence is required for recent movement.

**Review basis:** No keep bar has been agreed; native evidence is still reported.

**Outcome-matched costs:** Not measured. No cost-per-outcome or monetary return is inferred.

| Period ending, UTC | Persisted effects (effects) | Receipt-linked effects (effects) | Historical CLI comments (comments) | Persisted message lines (message lines) | Eligible opportunities | Evidence |
|---|---:|---:|---:|---:|---:|---|
| 2026-10-07T15:00:12Z | unknown | unknown | unknown | unknown | unknown | incomplete-evidence: No independently observed applicable native effect/opportunity in this period; missing is not zero. |
| 2026-10-08T15:00:12Z | unknown | unknown | unknown | unknown | unknown | incomplete-evidence: No independently observed applicable native effect/opportunity in this period; missing is not zero. |
| 2026-10-09T15:00:12Z | unknown | unknown | unknown | unknown | unknown | incomplete-evidence: No independently observed applicable native effect/opportunity in this period; missing is not zero. |
| 2026-10-10T15:00:12Z | unknown | unknown | unknown | unknown | unknown | incomplete-evidence: No independently observed applicable native effect/opportunity in this period; missing is not zero. |
| 2026-10-11T15:00:12Z | unknown | unknown | unknown | unknown | unknown | incomplete-evidence: No independently observed applicable native effect/opportunity in this period; missing is not zero. |
| 2026-10-12T15:00:12Z | unknown | unknown | unknown | unknown | unknown | incomplete-evidence: No independently observed applicable native effect/opportunity in this period; missing is not zero. |
| 2026-10-13T15:00:12Z | unknown | unknown | unknown | unknown | unknown | incomplete-evidence: No independently observed applicable native effect/opportunity in this period; missing is not zero. |
| 2026-10-14T15:00:12Z | unknown | unknown | unknown | unknown | unknown | incomplete-evidence: No independently observed applicable native effect/opportunity in this period; missing is not zero. |
| 2026-10-15T15:00:12Z | unknown | unknown | unknown | unknown | unknown | incomplete-evidence: No independently observed applicable native effect/opportunity in this period; missing is not zero. |
| 2026-10-16T15:00:12Z | unknown | unknown | unknown | unknown | unknown | incomplete-evidence: No independently observed applicable native effect/opportunity in this period; missing is not zero. |
| 2026-10-17T15:00:12Z | unknown | unknown | unknown | unknown | unknown | incomplete-evidence: No independently observed applicable native effect/opportunity in this period; missing is not zero. |
| 2026-10-18T15:00:12Z | unknown | unknown | unknown | unknown | unknown | incomplete-evidence: No independently observed applicable native effect/opportunity in this period; missing is not zero. |

The latest 12 periods are shown; the full native series is in the timeline.
Repository attainment includes other actors. Only a separately declared, independently verified contribution measure supports a workflow keep/change recommendation; it is not causal attribution.
Demonstrated workflow-enabled improvements count as shared contribution even when another agent or person implements them. Report measured progress, full goal completion, safeguards and attribution confidence separately. An unknown quality dimension does not cancel independently verified improvement; a merge alone does not verify that improvement.

## How to read the timeline

- Observations begin at workflow adoption on `2026-04-18`.
- No comparable pre-adoption evidence is available. Complete adjacent post-adoption periods may still show recent change, but not change relative to adoption.
- Each dot is one immutable observation. Missing evidence is omitted, never treated as zero.
- Execution activity is diagnostic only. It does not prove repository value.
- Recent change compares the immediately preceding equal-duration period, not lifetime movement. Interval windows must abut without overlap; snapshot values compare cutoff states.
- Two observations show observed change, not a sustained trend, statistical anomaly or target attainment. Unknown coverage, gaps and provisional evidence make comparison unavailable.
- Adoption comparison is separate. Stable-but-bad outcomes are not healthy merely because their latest delta is zero; workload-mix changes can explain aggregate movement.

## What was measured

**Goal:** For original deterministic smoke-ci sample opportunities, establish that configured safe-output requests produce their intended repository effects.

**Accepted outcome:** Retrospective fixed-reference five-sample predicates; primary is explicitly narrower persisted-effect progress, not full semantics.

### Persisted effects

- **What it tells you:** Persisted effects. This is a `primary` measure.
- **Native measurement formula:** `Number of distinct source-defined sample effects established independently in this interval; unknown population remains partial.`
- **Unit:** `effects`
- **Goal:** Higher values are better.
- **Chart display:** The chart shows the native value directly on a metric-specific axis.

### Receipt-linked effects

- **What it tells you:** Receipt-linked effects. This is a `diagnostic` measure.
- **Native measurement formula:** `Subset of persisted effects linked by original protected processing receipts to this workflow attempt.`
- **Unit:** `effects`
- **Goal:** Higher values are better.
- **Chart display:** The chart shows the native value directly on a metric-specific axis.

### Historical CLI comments

- **What it tells you:** Historical CLI comments. This is a `diagnostic` measure.
- **Native measurement formula:** `Additive historical partial facet: independently verified exact CLI comment on the original triggering PR. Never relabeled as a five-sample reference effect.`
- **Unit:** `comments`
- **Goal:** Higher values are better.
- **Chart display:** The chart shows the native value directly on a metric-specific axis.

### Persisted message lines

- **What it tells you:** Persisted message lines. This is a `diagnostic` measure.
- **Native measurement formula:** `Additive v3 native postcondition: unchanged PR comment contains one complete exact source-defined CLI message line; no protected execution/trigger-target claim.`
- **Unit:** `message lines`
- **Goal:** Higher values are better.
- **Chart display:** The chart shows the native value directly on a metric-specific axis.

## Evidence rules

- **Repository:** `github/gh-aw`
- **Evidence population:** Original run attempts whose exact head source and compiled replay establish applicability of this five-sample reference profile. Other eras remain unassessed, not failures.
- **Collection:** Offline byte/digest-verified original GitHub receipts and persisted state; bounded two-attempt partial population. No API calls or target code execution.
- **Observation window:** 1 days, sampled every 1 days
- **Maturation delay:** 0 days
- **Filters:** `Exact source-bound original run attempt and stable target identities`; `Retrospective reference profile; incompatible source eras are unavailable`; `No job-success, output-count, fixture or agent-explanation acceptance`

The frozen definitions and formulas are applied to every post-adoption observation. The structured evidence, exact snapshots, provenance, units, and native values are recorded in the adjacent `smoke-ci-timeline.json` artifact.

## Important limitation

This report can show whether the intended outcome is attained after adoption. It cannot estimate change from pre-adoption conditions or attribute attainment to the workflow.

Value-function SHA-256: `ec52879d626e67a8f964ab21693e9c286bc2b431f2c86c175bf72f95804153d7`
